ETSY SELLER FEE & PROFIT CALCULATOR
Æ Studio

WHAT THIS IS
Every Etsy fee, itemised, so you can see exactly where your money goes before you
list. Then it works backwards: tell it the profit you want, it tells you the price
to charge.

THE FIVE TABS
  Start Here        Setup in four steps
  Fee Settings      Every rate, editable. Change one cell when Etsy changes a fee.
  Quick Calculator  One item. Full fee breakdown, what you keep, break-even price.
  Price Finder      Reverse solve: profit you want -> price you need to list at.
  Bulk Calculator   Up to 100 listings at once, with totals and a below-break-even count.

THE FEES (US seller rates, verified 2026-07-25)
  Listing fee            $0.20 per listing, and again each time a sale renews it
  Transaction fee        6.5% of item price + shipping charged + gift wrap
  Payment processing     3% of that same base, plus $0.25 per order
  Offsite Ads            15% of the order, or 12% for shops over $10k/yr.
                         Charged ONLY on orders Etsy attributes to its offsite ad.
  Regulatory op fee      0% in the US. Non-zero in UK/FR/IT/ES/TR. Editable.

THE THING MOST SELLERS GET WRONG
Etsy charges its percentage fees on the shipping you collect, not just the item.
Moving money from the item price into the shipping price does not dodge the fee.

GOOGLE SHEETS
File - Import - Upload this file - "Replace spreadsheet". Every formula works.

VERIFICATION
Every formula was tested before this was listed. The fee engine was checked against
an independent calculation using exact decimal arithmetic: the itemised fees, the
totals, the break-even price, the reverse-solved list price, and the bulk rows all
matched to the cent, with Offsite Ads both on and off.

Rounding note, because it matters at the cent level: this file rounds each fee the
way Etsy's own billing does, half a cent always rounding up. On a $22.50 order the
3% processing fee is exactly $0.675 and becomes $0.68, not $0.67.

RATES CHANGE
Etsy changes its fees. This file does not expire, because every rate lives on the
Fee Settings tab. Edit the yellow cells and every calculation follows.

NOT FINANCIAL ADVICE
This is a calculator. It does the arithmetic Etsy does, so you can see it in advance.

SUPPORT
alexander.k.eliot@gmail.com - real answers, fast.

LICENSE
Personal and commercial use by the purchaser. No resale or redistribution of the
file itself.

DISCLOSURE
Designed by an AI-operated studio, human-reviewed. Every formula tested before listing.
