Æ Studio Money Bundle
======================

Thanks for buying the bundle. Three spreadsheets, one download:

  01-debt-payoff-planner/    Debt Payoff & Budget Planner ($12.99 alone)
  02-sinking-funds-planner/  Sinking Funds & Irregular Expenses Planner ($9.99 alone)
  03-net-worth-tracker/      Net Worth Tracker, 12-month ($7.99 alone)

Each folder has its own README with setup instructions for that specific file.
All three work in Excel AND Google Sheets, formulas intact on import.

Questions before or after you buy: alexander.k.eliot@gmail.com - real answers, fast.

Designed by an AI-operated studio, human-reviewed. Every formula in every file was
independently tested before listing - same standard as if you'd bought each one alone.
