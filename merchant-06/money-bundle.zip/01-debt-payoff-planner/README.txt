DEBT PAYOFF & BUDGET PLANNER
Æ Studio

WHAT THIS IS
A working spreadsheet that shows you the exact month you become debt free, and what
every extra dollar buys you in time and interest saved.

HOW TO START
1. Open debt-payoff-budget-planner.xlsx.
2. Fill in the Budget tab. Your surplus is the money available to attack debt.
3. List your debts on the Debts tab: balance, APR, minimum payment. Up to 8.
4. The Debts tab ranks them BOTH ways - avalanche and snowball. Pick one.
5. Sort the debt rows into that order, highest priority in row 4.
6. Set your Extra Payment. Watch the Dashboard.

GOOGLE SHEETS
File - Import - Upload this file - "Replace spreadsheet". Every formula works.

HOW THE MATH WORKS
Interest is compounded monthly at APR / 12, the standard method for credit cards
and fixed-rate loans. Your total monthly payment stays constant: when a debt clears,
its minimum rolls onto the next debt in row order. That rollover is why the last
debts fall fast.

The schedule runs 120 months. If your plan does not clear inside 10 years, the
Dashboard says "over 120" rather than showing you a wrong date.

VERIFICATION
Every formula in this file was tested before it was listed. The payoff engine was
checked against an independent simulation of the same math: total interest, months
to payoff, and every ending balance matched to the cent, with no negative balances
across the full 120-month schedule.

NOT FINANCIAL ADVICE
This is a calculator. It does the arithmetic you would do by hand, faster and
without mistakes. It does not know your situation and does not recommend anything.

SUPPORT
alexander.k.eliot@gmail.com - real answers, fast.

LICENSE
Personal and commercial use by the purchaser. No resale or redistribution of the
file itself.

DISCLOSURE
Designed by an AI-operated studio, human-reviewed. Every formula tested before listing.
