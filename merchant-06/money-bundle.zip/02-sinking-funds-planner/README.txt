SINKING FUNDS & IRREGULAR EXPENSES PLANNER
Æ Studio

WHAT THIS IS
A working spreadsheet for the expenses that aren't monthly but aren't a surprise
either: car registration, insurance premiums, Christmas. It tells you the fixed
amount to set aside every month so the money is already there when the bill is.

HOW TO START
1. Open sinking-funds-planner.xlsx.
2. On the Funds tab, list up to 10 funds: name, due month, target amount, what
   you've already saved.
3. The tab computes months remaining until each due date and the fixed monthly
   amount needed to hit the target exactly on time.
4. The Calendar tab spreads that amount across a rolling 12 months so you can see
   the total you need to move every month, across every fund at once.
5. The Dashboard shows the total due this month and how fully funded you are
   overall.

GOOGLE SHEETS
File - Import - Upload this file - "Replace spreadsheet". Every formula works.

HOW THE MATH WORKS
Months remaining = whole months from today to the due date, floored at 1 (a fund
due this month still shows a real number, not zero or a negative). Monthly
set-aside = (target - already saved) / months remaining. The Calendar tab spreads
that fixed monthly amount across a rolling 12-month window starting this month, for
exactly as many columns as "months remaining" - capped visually at 12, but a fund
due further out still contributes correctly to this month's total.

VERIFICATION
Every formula in this file was tested before it was listed, checked against an
independent Python simulation of the same math across four scenarios: a fund due
next month, a fund due exactly today (the floor-at-1 edge case), a fund already
partially funded, and a fund due more than a year out. Every months-remaining
figure, every monthly set-aside amount, and every rolling-calendar total matched to
the cent.

NOT FINANCIAL ADVICE
This is a calculator. It does the arithmetic you would do by hand, faster and
without mistakes. It does not know your situation and does not recommend anything.

SUPPORT
alexander.k.eliot@gmail.com - real answers, fast.

LICENSE
Personal and commercial use by the purchaser. No resale or redistribution of the
file itself.

DISCLOSURE
Designed by an AI-operated studio, human-reviewed. Every formula tested before listing.
