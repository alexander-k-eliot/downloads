=== AI Visibility Check ===
Contributors: alexanderkeliot
Tags: ai visibility, geo, aeo, schema, ai search
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Check how visible your site is to AI assistants like ChatGPT, Perplexity, and Gemini. Evidence-based checks, no data collection.

== Description ==

37% of consumers now start searches in AI assistants, and AI referral traffic converts several times better than classic search. But most sites were never checked for the basics AI systems actually read.

AI Visibility Check runs 8 evidence-based checks against your own site, from your own server:

* Homepage returns readable HTML (not JavaScript-only)
* robots.txt does not block major AI crawlers (GPTBot, ClaudeBot, PerplexityBot, OAI-SearchBot, Google-Extended)
* Structured data (JSON-LD) present
* Entity and FAQ schema types (Organization, LocalBusiness, FAQPage, Product, Service)
* Clear title tag and meta description
* H1 heading present
* An early self-contained paragraph an AI could actually quote
* XML sitemap reachable

You get a 0-100 score and plain-English fixes for anything that fails.

**What this plugin deliberately does NOT do:** it does not score llms.txt. Independent large-scale studies (500M+ AI bot visits; 300K-domain correlation analysis) show AI crawlers almost never fetch that file and it has no measured effect on citations. We check what the evidence supports, not what is fashionable.

**Honesty note:** nothing can guarantee AI citations or recommendations. This plugin reports the measurable conditions AI systems read, and nothing else.

**Privacy:** all checks run from your server against your own site. The plugin sends no data anywhere, sets no cookies, calls no external APIs, and collects nothing.

The plugin is developed by an AI-operated, human-reviewed studio. The report footer links to the studio's optional paid services (manual deep audits and monitoring); the plugin is complete and free without them.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`, or install via Plugins > Add New.
2. Activate the plugin.
3. Go to Tools > AI Visibility Check and click "Run Check".

== Frequently Asked Questions ==

= Does this plugin send my data anywhere? =

No. Every check runs from your own server against your own site's public pages (homepage, robots.txt, sitemap). No external services, no tracking, no data collection.

= Will this get me cited by ChatGPT? =

Nobody can promise that, and you should distrust anyone who does. The plugin checks the published, evidence-supported conditions that make citation possible: crawler access, readable HTML, structured data, and extractable answers.

= Why doesn't it check llms.txt? =

Because the evidence says it does not matter: analyses of hundreds of millions of AI crawler visits found the file is almost never fetched, and a 300,000-domain study found no correlation with citations. Google has said on record it does not use it. We do not score theater.

== Changelog ==

= 1.0.0 =
* Initial release: 8 evidence-based AI visibility checks with scored report.
