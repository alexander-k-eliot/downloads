=== AI Visibility Check ===
Contributors: alexanderkeliot
Tags: ai visibility, geo, aeo, schema, ai search
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Check AND fix how visible your site is to AI assistants like ChatGPT, Perplexity, and Gemini. Evidence-based checks, one-click AI-crawler allow rule, ready-to-paste JSON-LD.

== Description ==

A 2026 consumer survey found 37% of people now start searches in AI assistants instead of Google, and AI referral traffic converts several times better than classic search. But most sites were never checked for the basics AI systems actually read, and most "AI visibility" tools only tell you what's wrong. This one fixes what it can, right from the same screen.

AI Visibility Check runs 8 evidence-based checks against your own site, from your own server:

* Homepage returns readable HTML (not JavaScript-only)
* robots.txt does not block major AI crawlers (GPTBot, ClaudeBot, PerplexityBot, OAI-SearchBot, Google-Extended)
* Structured data (JSON-LD) present
* Entity and FAQ schema types (Organization, LocalBusiness, FAQPage, Product, Service)
* Clear title tag and meta description
* H1 heading present
* An early self-contained paragraph an AI could actually quote
* XML sitemap reachable

You get a 0-100 score and plain-English fixes for anything that fails — plus two one-click fixes:

* **Allow AI crawlers**: a single checkbox that adds an explicit Allow rule for GPTBot, ClaudeBot, PerplexityBot, and others to your site's robots.txt (works with WordPress's built-in virtual robots.txt).
* **Paste-ready JSON-LD**: if structured data is missing, the plugin builds a real Organization schema block from your own homepage title and meta description — never a fabricated fact — ready to paste into your theme.

**What this plugin deliberately does NOT do:** it does not score llms.txt. Independent large-scale studies (500M+ AI bot visits; 300K-domain correlation analysis) show AI crawlers almost never fetch that file and it has no measured effect on citations. We check what the evidence supports, not what is fashionable.

**Honesty note:** nothing can guarantee AI citations or recommendations. This plugin reports the measurable conditions AI systems read, and nothing else.

**Privacy:** all checks and fixes run from your server against your own site. The plugin sends no data anywhere, sets no cookies, calls no external APIs, and collects nothing. The JSON-LD snippet and robots.txt rule are generated and displayed locally; nothing is transmitted to us or anyone else.

The plugin is developed by an AI-operated, human-reviewed studio. The report footer links to the studio's optional paid services (manual deep audits and monitoring); the plugin is complete and free without them.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`, or install via Plugins > Add New.
2. Activate the plugin.
3. Go to Tools > AI Visibility Check and click "Run Check".

== Frequently Asked Questions ==

= Does this plugin send my data anywhere? =

No. Every check and fix runs from your own server against your own site's public pages (homepage, robots.txt, sitemap). No external services, no tracking, no data collection.

= How does the "allow AI crawlers" fix work? =

WordPress generates a virtual robots.txt for sites that don't have a physical robots.txt file on the server — that's the vast majority of installs. When you check the box, the plugin adds an explicit Allow rule for GPTBot, ClaudeBot, PerplexityBot, and other AI assistant crawlers to that virtual output. If your site has a real robots.txt file uploaded to the server, WordPress doesn't call this filter at all, so you'll need to edit that file directly — the plugin's report tells you exactly which crawlers to allow.

= Where does the JSON-LD snippet's data come from? =

Your own homepage's <title> tag and meta description, fetched fresh when you run the check. If either isn't confidently found, it's left out of the snippet rather than guessed — this plugin never invents a business fact.

= Will this get me cited by ChatGPT? =

Nobody can promise that, and you should distrust anyone who does. The plugin checks the published, evidence-supported conditions that make citation possible: crawler access, readable HTML, structured data, and extractable answers.

= Why doesn't it check llms.txt? =

Because the evidence says it does not matter: analyses of hundreds of millions of AI crawler visits found the file is almost never fetched, and a 300,000-domain study found no correlation with citations. Google has said on record it does not use it. We do not score theater.

== Changelog ==

= 1.1.0 =
* Added one-click fix: allow AI assistant crawlers in robots.txt (works with WordPress's built-in virtual robots.txt).
* Added paste-ready JSON-LD snippet generator, built from the site's own homepage title and meta description.
* Updated paid-services link (full audit is now the AI-Readiness Retrofit product, not a marketplace gig).

= 1.0.0 =
* Initial release: 8 evidence-based AI visibility checks with scored report.

== Upgrade Notice ==

= 1.1.0 =
Adds one-click fixes (AI-crawler robots.txt rule, JSON-LD generator) alongside the original checks. No settings are changed on upgrade; the new robots.txt rule is off by default.
