<?php
/**
 * Plugin Name: AI Visibility Check
 * Plugin URI:  https://alexander-k-eliot.github.io/
 * Description: Check AND fix how visible your site is to AI assistants like ChatGPT, Perplexity, and Gemini. Evidence-based checks, one-click AI-crawler allow rule, and a ready-to-paste JSON-LD snippet. No data leaves your site.
 * Version:     1.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author:      Alexander K. Eliot
 * Author URI:  https://alexander-k-eliot.github.io/
 * License:     GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ai-visibility-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AIVC_Plugin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_filter( 'robots_txt', array( __CLASS__, 'maybe_allow_ai_crawlers' ), 10, 2 );
	}

	/**
	 * One-click fix: append an explicit Allow block for AI crawlers to WordPress's own
	 * virtual robots.txt output, if the site owner has opted in. Only fires for WordPress's
	 * generated robots.txt (no physical robots.txt file on disk) — WP itself only calls this
	 * filter in that case, so there is nothing to detect or warn about here.
	 */
	public static function maybe_allow_ai_crawlers( $output, $public ) {
		if ( ! get_option( 'aivc_allow_ai_crawlers' ) ) {
			return $output;
		}
		$bots = array( 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-User', 'PerplexityBot', 'Google-Extended', 'anthropic-ai' );
		$block = "\n# Added by AI Visibility Check plugin — explicit allow for AI assistant crawlers.\n";
		foreach ( $bots as $bot ) {
			$block .= "User-agent: {$bot}\nAllow: /\n\n";
		}
		return rtrim( $output ) . "\n" . $block;
	}

	public static function add_menu() {
		add_management_page(
			__( 'AI Visibility Check', 'ai-visibility-check' ),
			__( 'AI Visibility Check', 'ai-visibility-check' ),
			'manage_options',
			'ai-visibility-check',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['aivc_toggle_allow'] ) && check_admin_referer( 'aivc_toggle_allow', 'aivc_toggle_nonce' ) ) {
			update_option( 'aivc_allow_ai_crawlers', isset( $_POST['aivc_allow_ai_crawlers'] ) ? 1 : 0 );
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Setting saved.', 'ai-visibility-check' ) . '</p></div>';
		}

		$results = null;
		$html    = '';
		if ( isset( $_POST['aivc_run'] ) && check_admin_referer( 'aivc_run_check', 'aivc_nonce' ) ) {
			list( $results, $html ) = self::run_checks();
		}

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'AI Visibility Check', 'ai-visibility-check' ) . '</h1>';
		echo '<p>' . esc_html__( 'Evidence-based checks AND fixes for how readable and quotable your site is for AI assistants (ChatGPT, Perplexity, Gemini, Claude). All checks run from your own server against your own site. Nothing is sent anywhere.', 'ai-visibility-check' ) . '</p>';

		echo '<form method="post">';
		wp_nonce_field( 'aivc_run_check', 'aivc_nonce' );
		submit_button( __( 'Run Check', 'ai-visibility-check' ), 'primary', 'aivc_run' );
		echo '</form>';

		echo '<form method="post" style="margin-top:8px">';
		wp_nonce_field( 'aivc_toggle_allow', 'aivc_toggle_nonce' );
		echo '<label><input type="checkbox" name="aivc_allow_ai_crawlers" value="1" ' . checked( 1, get_option( 'aivc_allow_ai_crawlers' ), false ) . ' /> ';
		echo esc_html__( 'One-click fix: explicitly allow AI assistant crawlers (GPTBot, ClaudeBot, PerplexityBot, and others) in robots.txt', 'ai-visibility-check' );
		echo '</label> ';
		submit_button( __( 'Save', 'ai-visibility-check' ), 'secondary', 'aivc_toggle_allow', false );
		echo '<p class="description">' . esc_html__( 'Only takes effect if your site uses WordPress\'s built-in robots.txt (no physical robots.txt file uploaded to your server).', 'ai-visibility-check' ) . '</p>';
		echo '</form>';

		if ( is_array( $results ) ) {
			self::render_results( $results, $html );
		}

		echo '</div>';
	}

	private static function run_checks() {
		$checks   = array();
		$home     = home_url( '/' );

		// --- Fetch homepage HTML (own site only). ---
		$response = wp_remote_get( $home, array( 'timeout' => 15, 'user-agent' => 'AI-Visibility-Check-Plugin/1.0 (self-check)' ) );
		$html     = ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) )
			? wp_remote_retrieve_body( $response ) : '';

		// 1. Homepage reachable / renders HTML.
		$checks[] = array(
			'label' => __( 'Homepage returns readable HTML', 'ai-visibility-check' ),
			'pass'  => '' !== $html,
			'weight'=> 15,
			'fix'   => __( 'AI crawlers read plain HTML. If your homepage does not return HTML (or requires JavaScript for all content), most AI crawlers see nothing.', 'ai-visibility-check' ),
		);

		// 2. robots.txt does not block major AI crawlers.
		$robots_resp = wp_remote_get( home_url( '/robots.txt' ), array( 'timeout' => 10 ) );
		$robots      = ( ! is_wp_error( $robots_resp ) ) ? strtolower( wp_remote_retrieve_body( $robots_resp ) ) : '';
		$blocked     = array();
		foreach ( array( 'gptbot', 'claudebot', 'perplexitybot', 'oai-searchbot', 'google-extended' ) as $bot ) {
			if ( preg_match( '/user-agent:\s*' . preg_quote( $bot, '/' ) . '\s+disallow:\s*\/\s/i', $robots . "\n" ) ) {
				$blocked[] = $bot;
			}
		}
		$checks[] = array(
			'label' => __( 'AI crawlers are not blocked in robots.txt', 'ai-visibility-check' ),
			'pass'  => empty( $blocked ),
			'weight'=> 15,
			'fix'   => empty( $blocked )
				? ''
				: sprintf( /* translators: %s: list of blocked bots */ __( 'Blocked: %s. If you want AI assistants to cite you, allow these crawlers.', 'ai-visibility-check' ), implode( ', ', $blocked ) ),
		);

		// 3. Structured data present (JSON-LD).
		$has_jsonld = ( '' !== $html ) && false !== stripos( $html, 'application/ld+json' );
		$checks[] = array(
			'label' => __( 'Structured data (JSON-LD schema) present', 'ai-visibility-check' ),
			'pass'  => $has_jsonld,
			'weight'=> 15,
			'fix'   => __( 'Schema markup helps AI systems identify who you are, what you offer, and what to quote. An SEO plugin or manual JSON-LD block fixes this.', 'ai-visibility-check' ),
		);

		// 4. Organization/LocalBusiness/FAQ schema types.
		$rich_types = ( '' !== $html ) && preg_match( '/"@type"\s*:\s*"?(Organization|LocalBusiness|FAQPage|Product|Service)/i', $html );
		$checks[] = array(
			'label' => __( 'Entity or FAQ schema types found (Organization, LocalBusiness, FAQPage, Product, Service)', 'ai-visibility-check' ),
			'pass'  => (bool) $rich_types,
			'weight'=> 10,
			'fix'   => __( 'Generic schema is a start; entity types (Organization/LocalBusiness) and FAQPage are what AI answers most often draw from.', 'ai-visibility-check' ),
		);

		// 5. Title + meta description.
		$has_title = ( '' !== $html ) && preg_match( '/<title[^>]*>.{5,}<\/title>/is', $html );
		$has_desc  = ( '' !== $html ) && preg_match( '/<meta[^>]+name=["\']description["\'][^>]+content=["\'].{20,}/i', $html );
		$checks[] = array(
			'label' => __( 'Clear title tag and meta description', 'ai-visibility-check' ),
			'pass'  => $has_title && $has_desc,
			'weight'=> 10,
			'fix'   => __( 'Title and description are the first entity signals AI systems read. Say plainly who you are and what you do.', 'ai-visibility-check' ),
		);

		// 6. H1 present.
		$has_h1 = ( '' !== $html ) && preg_match( '/<h1[\s>]/i', $html );
		$checks[] = array(
			'label' => __( 'H1 heading present on homepage', 'ai-visibility-check' ),
			'pass'  => (bool) $has_h1,
			'weight'=> 10,
			'fix'   => __( 'Headings give AI systems the structure they use to extract answers.', 'ai-visibility-check' ),
		);

		// 7. Extractable answer heuristic: an early substantive paragraph.
		$extractable = false;
		if ( '' !== $html && preg_match_all( '/<p[^>]*>(.*?)<\/p>/is', $html, $m ) ) {
			foreach ( array_slice( $m[1], 0, 6 ) as $p ) {
				$text = trim( wp_strip_all_tags( $p ) );
				if ( strlen( $text ) >= 80 && strlen( $text ) <= 600 ) {
					$extractable = true;
					break;
				}
			}
		}
		$checks[] = array(
			'label' => __( 'Early self-contained paragraph an AI could quote', 'ai-visibility-check' ),
			'pass'  => $extractable,
			'weight'=> 15,
			'fix'   => __( 'AI assistants quote sentences that stand alone. Lead your page with a direct 1-3 sentence answer to "what is this and who is it for".', 'ai-visibility-check' ),
		);

		// 8. Sitemap available.
		$sitemap_resp = wp_remote_head( home_url( '/wp-sitemap.xml' ), array( 'timeout' => 10 ) );
		$has_sitemap  = ! is_wp_error( $sitemap_resp ) && in_array( wp_remote_retrieve_response_code( $sitemap_resp ), array( 200, 301, 302 ), true );
		$checks[] = array(
			'label' => __( 'XML sitemap reachable', 'ai-visibility-check' ),
			'pass'  => $has_sitemap,
			'weight'=> 10,
			'fix'   => __( 'Sitemaps help crawlers of every kind find your content. WordPress ships one by default at /wp-sitemap.xml unless disabled.', 'ai-visibility-check' ),
		);

		return array( $checks, $html );
	}

	/**
	 * Builds a ready-to-paste JSON-LD snippet from real data already fetched from the site's
	 * own homepage (title, meta description). Never fabricates a business fact — anything not
	 * confidently extractable is left out of the block entirely rather than guessed.
	 */
	private static function build_jsonld_snippet( $html ) {
		$title = '';
		if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $m ) ) {
			$title = trim( wp_strip_all_tags( $m[1] ) );
		}
		$desc = '';
		if ( preg_match( '/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']+)/i', $html, $m ) ) {
			$desc = trim( $m[1] );
		}
		$block = array(
			'@context' => 'https://schema.org',
			'@type'    => 'Organization',
			'name'     => '' !== $title ? $title : get_bloginfo( 'name' ),
			'url'      => home_url( '/' ),
		);
		if ( '' !== $desc ) {
			$block['description'] = $desc;
		}
		return "<script type=\"application/ld+json\">\n" . wp_json_encode( $block, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . "\n</script>";
	}

	private static function render_results( $checks, $html = '' ) {
		$score = 0;
		$max   = 0;
		foreach ( $checks as $c ) {
			$max += $c['weight'];
			if ( $c['pass'] ) {
				$score += $c['weight'];
			}
		}
		$pct = $max > 0 ? (int) round( 100 * $score / $max ) : 0;

		echo '<hr />';
		/* translators: %d: score percentage */
		echo '<h2>' . esc_html( sprintf( __( 'Score: %d / 100', 'ai-visibility-check' ), $pct ) ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:900px">';
		echo '<thead><tr><th>' . esc_html__( 'Check', 'ai-visibility-check' ) . '</th><th>' . esc_html__( 'Result', 'ai-visibility-check' ) . '</th></tr></thead><tbody>';
		foreach ( $checks as $c ) {
			echo '<tr><td>' . esc_html( $c['label'] );
			if ( ! $c['pass'] && ! empty( $c['fix'] ) ) {
				echo '<br /><em style="color:#666">' . esc_html( $c['fix'] ) . '</em>';
			}
			echo '</td><td>' . ( $c['pass'] ? '<span style="color:green">&#10003; ' . esc_html__( 'Pass', 'ai-visibility-check' ) . '</span>' : '<span style="color:#c00">&#10007; ' . esc_html__( 'Needs work', 'ai-visibility-check' ) . '</span>' ) . '</td></tr>';
		}
		echo '</tbody></table>';

		$jsonld_check = null;
		foreach ( $checks as $c ) {
			if ( false !== stripos( $c['label'], 'Structured data' ) ) {
				$jsonld_check = $c;
				break;
			}
		}
		if ( $jsonld_check && ! $jsonld_check['pass'] && '' !== $html ) {
			echo '<h3>' . esc_html__( 'Fix it now: paste-ready JSON-LD', 'ai-visibility-check' ) . '</h3>';
			echo '<p class="description">' . esc_html__( 'Built from your own homepage title and meta description — nothing invented. Paste this into your theme\'s header (or a custom HTML block) before the closing </head> tag.', 'ai-visibility-check' ) . '</p>';
			echo '<textarea readonly rows="8" style="width:100%;max-width:900px;font-family:monospace" onclick="this.select()">' . esc_textarea( self::build_jsonld_snippet( $html ) ) . '</textarea>';
		}

		echo '<p style="margin-top:16px;color:#555">' . esc_html__( 'Honest note: no tool or service can guarantee AI citations or recommendations. These checks reflect published evidence about what AI systems actually read. One much-hyped file, llms.txt, is deliberately NOT scored here: large studies show AI crawlers almost never fetch it.', 'ai-visibility-check' ) . '</p>';

		echo '<p><strong>' . esc_html__( 'Want the deep version?', 'ai-visibility-check' ) . '</strong> ';
		echo wp_kses(
			sprintf(
				/* translators: %s: retrofit product URL */
				__( 'The developer of this plugin (an AI-operated studio, human-reviewed) offers a <a href="%s" target="_blank" rel="noopener">paid AI-readiness retrofit</a> covering the fixes above and more. The plugin is complete and free either way.', 'ai-visibility-check' ),
				'https://eliotwave01.gumroad.com/l/zarfs'
			),
			array( 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
		);
		echo '</p>';

		echo '<p class="description">' . wp_kses(
			sprintf(
				/* translators: %s: browser toolkit URL */
				__( 'Prefer a browser tool? The same checks, plus a schema generator, robots.txt generator and reseller fee calculator, run free at <a href="%s" target="_blank" rel="noopener">the AI Visibility Check toolkit</a>.', 'ai-visibility-check' ),
				'https://alexander-k-eliot.github.io/ai-visibility-check-free/'
			),
			array( 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
		) . '</p>';
	}
}

AIVC_Plugin::init();
