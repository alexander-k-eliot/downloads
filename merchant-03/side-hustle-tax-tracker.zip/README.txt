SIDE-HUSTLE INCOME & EXPENSE TRACKER (TAX-READY)
Æ Studio

WHAT THIS IS
Bookkeeping for a side business, built around the actual IRS Schedule C, plus an
honest estimate of what to set aside so April is not a surprise.

THE SEVEN TABS
  Start Here          How it works, in five steps
  Settings            Every rate you control. Update these each January.
  Income              Log money in, gross and net of platform fees
  Expenses            Log money out against real Schedule C categories
  Mileage             Date, destination, purpose, miles -> deduction
  Schedule C Summary  Totals by real Schedule C line number
  Tax Estimate        What to set aside, and what share of every dollar
  Quarterly Taxes     The four estimated payments and their due dates

WHAT IS COMPUTED EXACTLY, AND WHAT IS NOT
This distinction is the whole design, so it is worth stating plainly.

  COMPUTED EXACTLY - self-employment tax. The 92.35% net-earnings factor, the
  12.4% Social Security rate, the Social Security wage-base cap, the 2.9%
  Medicare rate, the 0.9% Additional Medicare surtax and the deductible half of
  SE tax are all set by statute. This file does that arithmetic in full.

  YOU SUPPLY - your federal and state income tax rate. Brackets change every
  year and depend on filing status, deductions, credits and household income
  this file cannot see. Guessing them would hand you a confident wrong number
  on a tax product, which is the worst thing this file could do. So you enter
  your rate and the Settings tab tells you where to find it.

WHAT IT DOES NOT MODEL
  - The qualified business income deduction, which may reduce what you owe
  - Progressive brackets (the income tax line uses your flat rate)
  - Home-office deduction, depreciation schedules, inventory accounting
  - Anything state-specific beyond a flat state rate
Ask an accountant about these. This file exists to make that conversation short.

RATES THAT CHANGE EVERY YEAR
  - Social Security wage base
  - Standard mileage rate (IRS publishes it each December for the next year)
  - Income tax brackets
All three live on Settings. The file does not expire. It does need five minutes
each January.

GOOGLE SHEETS
File - Import - Upload this file - "Replace spreadsheet". Every formula works.

VERIFICATION
Every formula was tested before this was listed. The tax engine was checked
against an independent implementation using exact decimal arithmetic, across
four scenarios: an ordinary year, a partially used Social Security wage base, a
fully exhausted wage base, and income above the Additional Medicare threshold.
Schedule C category routing, the business-use percentage, and the mileage
deduction folding into line 9 were verified too. Everything matched to the cent.

NOT TAX ADVICE
This is a bookkeeping tool with an estimate attached. It is not tax software, it
does not file anything, and it is not a substitute for an accountant. Erring
high on what you set aside is the safe direction.

SUPPORT
alexander.k.eliot@gmail.com - real answers, fast.

LICENSE
Personal and commercial use by the purchaser. No resale or redistribution of the
file itself.

DISCLOSURE
Designed by an AI-operated studio, human-reviewed. Every formula tested before listing.
