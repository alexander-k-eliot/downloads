NET WORTH TRACKER (12-MONTH)
Æ Studio

WHAT THIS IS
One number, tracked honestly for twelve months. Assets minus liabilities, with
the arithmetic done for you and a dashboard that shows which way the line is
going.

THE FOUR TABS
  Start Here   How it works, and what counts as an asset or a liability
  Accounts     List your accounts ONCE. Mark each Asset or Liability.
  Snapshots    Fill in one column a month. That is the whole habit.
  Dashboard    Net worth now, change so far, month by month, best and worst

HOW TO USE IT
1. Set up your accounts on the Accounts tab. Overwrite the examples.
2. Once a month, on the same day, fill in one column on Snapshots.
3. Read the Dashboard.

That is it. The design is deliberately small, because the thing that makes a net
worth tracker work is filling it in every month, and complicated files do not get
filled in.

A NOTE ON THE NUMBER
Net worth can be negative, and for a lot of people it starts that way. Student
loans and a mortgage put most households below zero for years. The line moving
up is the point, not the number itself.

DO NOT OVERTHINK IT
Round to the nearest dollar. Skip anything genuinely hard to value. A rough
number entered every month beats a perfect number you stop entering in March.

PARTIAL YEARS ARE FINE
Leave future months blank. The Dashboard works out how many months you have
filled in and reports against the latest one. Starting in June is fine.

NEXT YEAR
Save a copy, clear the Snapshots grid, keep your accounts. Nothing in this file
is tied to a particular year.

GOOGLE SHEETS
File - Import - Upload this file - "Replace spreadsheet". Every formula works.

VERIFICATION
Every formula was tested before this was listed. Monthly asset, liability and
net worth totals, the change column, the running total, the average per month
and the best/worst month lookups were all checked against an independent
calculation and matched to the cent. The partial-year case was tested directly,
with both three months and a single month of data, because a half-filled sheet
is the normal state of this product, not an edge case.

SUPPORT
alexander.k.eliot@gmail.com - real answers, fast.

LICENSE
Personal and commercial use by the purchaser. No resale or redistribution of the
file itself.

DISCLOSURE
Designed by an AI-operated studio, human-reviewed. Every formula tested before listing.
